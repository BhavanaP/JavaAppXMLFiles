<?php 
session_start(); 
?> 
<?php 
 $hostname="localhost";
$username="bpallepati1";
$dbname="bpallepati1";
$password="1db23";

$sid=$_POST["sid"]; 
$sname=$_POST["sname"]; 
$courseno=$_POST["courseno"]; 
$status=$_POST["status"]; 
$hobbies=$_POST["hobbies"]; 
$conn = new mysqli($hostname, $username, $password, $dbname);
$array = implode(',',$courseno);$array1 = implode(',',$hobbies);
 if ($conn->connect_error) 
{
die("Connection failed: ". $conn->connect_error);
 }
$query="INSERT INTO form_2(sid,sname,status) values('$sid','$sname','$status')";
 $query1=("INSERT INTO checkbox_2(sid,checkboxes_name,checkbox_value) values('$sid','courseno','$array')");
 $query2="INSERT INTO multibox_2(sid,multibox_name,multi_values) values('$sid','hobbies','$array1')";
 if($conn->query($query) === TRUE){echo '<br>record created for form_2 table<br>';
 } 
else 
 { 
 echo"error:" . $query . "<br><br>" . $conn->error;
}

 if($conn->query($query1) === TRUE){echo 'record created for checkbox_2 table<br>';
 } 
else 
 { 
 echo"error:" . $query1 . "<br><br>" . $conn->error;
}
 
 if($conn->query($query2) === TRUE){echo 'record created for multibox_2';
 } 
else 
 { 
 echo"error:" . $query2 . "<br><br>" . $conn->error;
}
 $conn->close(); 

?>