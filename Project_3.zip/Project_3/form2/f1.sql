DROP TABLE IF EXISTS form_2;
CREATE TABLE form_2(sid int(4) NOT NULL,
sname varchar(50) NOT NULL,
status varchar(200) NOT NULL,
PRIMARY KEY (sid)
);
 DROP TABLE IF EXISTS checkbox_2; 
 CREATE TABLE checkbox_2( sid int(4) NOT NULL, 
checkboxes_name varchar(200) NOT NULL,
checkbox_value varchar(200) NOT NULL,
CONSTRAINT FK_checkbox_2 FOREIGN KEY (sid)REFERENCES form_2 (sid));
 
 DROP TABLE IF EXISTS multibox_2; 
 CREATE TABLE multibox_2( sid int(4) NOT NULL, 
multibox_name varchar(200) NOT NULL,
 multi_values varchar(200) NOT NULL,
CONSTRAINT FK_multibox_2 FOREIGN KEY (sid)REFERENCES form_2 (sid));