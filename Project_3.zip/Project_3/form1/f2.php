<?php 
session_start(); 
?> 
<?php 
 $hostname="localhost";
$username="bpallepati1";
$dbname="bpallepati1";
$password="1db23";

$connection = new mysqli($hostname, $username, $password, $dbname);

 if ($connection->connect_error) 
{
die("Connection failed: ". $connection->connect_error);
 }
$p="SELECT * from "; 
 
 $q=array("form_1","checkbox_1"); 
$n=1;

 for($i=0;$i<=$n;$i++)
 { 
 $query=$p.$q[$i]; 
echo $query; 

 if ($res=mysqli_query($connection,$query)) 
 {
 $count=mysqli_num_fields($res);
 printf("<table  border=1><tr>");while ($col=mysqli_fetch_field($res)) 
 {echo "<th>$col->name</th>"; 
 }
 printf ("</tr>");
 while ($value=mysqli_fetch_row($res))
 { 
  printf ("<tr>");
 for($j=0; $j<$count; $j++)
 { 
 printf("<td>"); 
 echo "$value[$j]"; 
 
  printf("</td>"); 
 } 
 printf("</tr>"); 
 } 
 printf("</table>"); 
 mysqli_free_result($res); 
} 
}mysqli_close($connection)
?>