DROP TABLE IF EXISTS form_1;
CREATE TABLE form_1(firstname varchar(50) NOT NULL,
lastname varchar(50) NOT NULL,
sno varchar(9) NOT NULL,
status varchar(200) NOT NULL,
semester varchar(200) NOT NULL,
PRIMARY KEY (sno)
);
 DROP TABLE IF EXISTS checkbox_1; 
 CREATE TABLE checkbox_1( sno varchar(9) NOT NULL, 
checkboxes_name varchar(200) NOT NULL,
checkbox_value varchar(200) NOT NULL,
CONSTRAINT FK_checkbox_1 FOREIGN KEY (sno)REFERENCES form_1 (sno))