<?php 
session_start(); 
?> 
<?php 
 $hostname="localhost";
$username="bpallepati1";
$dbname="bpallepati1";
$password="1db23";

$firstname=$_POST["firstname"]; 
$lastname=$_POST["lastname"]; 
$sno=$_POST["sno"]; 
$courseno=$_POST["courseno"]; 
$status=$_POST["status"]; 
$semester=$_POST["semester"]; 
$conn = new mysqli($hostname, $username, $password, $dbname);
$array = implode(',',$courseno);
 if ($conn->connect_error) 
{
die("Connection failed: ". $conn->connect_error);
 }
$query="INSERT INTO form_1(firstname,lastname,sno,status,semester) values('$firstname','$lastname','$sno','$status','$semester')";
 $query1=("INSERT INTO checkbox_1(sno,checkboxes_name,checkbox_value) values('$sno','courseno','$array')");
 if($conn->query($query) === TRUE){echo '<br>record created for form_1 table<br>';
 } 
else 
 { 
 echo"error:" . $query . "<br><br>" . $conn->error;
}

 if($conn->query($query1) === TRUE){echo 'record created for checkbox_1 table<br>';
 } 
else 
 { 
 echo"error:" . $query1 . "<br><br>" . $conn->error;
}
 